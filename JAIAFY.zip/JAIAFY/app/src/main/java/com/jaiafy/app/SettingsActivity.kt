package com.jaiafy.app
import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** إعدادات مخفية: تُفتح بالضغط المطول على الكرة. الحقول الفارغة لا تمسح القيم المحفوظة. */
class SettingsActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val cy = 0xFF5FE3FF.toInt()
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(24)) }
        form.addView(TextView(this).apply { text = "إعدادات جايفاي"; setTextColor(cy); textSize = 18f; setPadding(0, 0, 0, dp(12)) })
        fun field(h: String, pass: Boolean) = EditText(this).apply {
            hint = h; setTextColor(-1); setHintTextColor(0xFF668899.toInt()); textSize = 14f
            setBackgroundColor(0x22FFFFFF)
            inputType = if (pass) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
            form.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        fun btn(t: String, f: () -> Unit) {
            form.addView(Button(this).apply {
                text = t; isAllCaps = false; setTextColor(cy); textSize = 14f
                background = GradientDrawable().apply { cornerRadius = 10 * d; setColor(0x33104060); setStroke(dp(1), cy) }
                setOnClickListener { f() }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        val fKey = field("مفتاح OpenRouter (sk-or-...)", true)
        val fModel = field("النموذج (اتركه فارغاً للافتراضي)", false)
        val fFish = field("مفتاح Fish Audio (اختياري)", true)
        val fVoice = field("معرّف صوت Fish (اختياري)", false)
        val fCam = field("رابط كاميرا المراقبة rtsp://...", false)
        val fHaUrl = field("رابط Home Assistant http://192.168.x.x:8123", false)
        val fHaTok = field("توكن Home Assistant", true)
        val fHaEnt = field("كيان النور مثل light.salon", false)
        fun save(k: String, f: EditText) { if (f.text.isNotBlank()) Brain.put(this, k, f.text.toString()) }
        btn("حفظ") {
            if (fKey.text.isNotBlank()) Brain.saveKey(this, fKey.text.toString())
            if (fModel.text.isNotBlank()) Brain.saveModel(this, fModel.text.toString())
            save("fish_key", fFish); save("fish_voice", fVoice); save("cam_url", fCam)
            save("ha_url", fHaUrl); save("ha_token", fHaTok); save("ha_entity", fHaEnt)
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
        }
        btn("تفعيل التحكم بالشاشة") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("السماح بالظهور فوق التطبيقات") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF02070D.toInt()); addView(form) })
    }
}
