package com.jaiafy.app
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** الشاشة الرئيسية: الكرة الزرقاء فقط. ضغطة مطولة عليها تفتح الإعدادات. تُفتح بقفل الوجه. */
class MainActivity : FragmentActivity() {
    private val need = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA,
        Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.CALL_PHONE)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val weak = BiometricManager.Authenticators.BIOMETRIC_WEAK
        if (BiometricManager.from(this).canAuthenticate(weak) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "سجّل بصمة وجهك في إعدادات الجوال أولاً", Toast.LENGTH_LONG).show()
            finish(); return
        }
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) = buildUi()
            override fun onAuthenticationError(c: Int, m: CharSequence) = finish()
        }).authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("جايفاي")
            .setSubtitle("ضع وجهك أمام الكاميرا")
            .setNegativeButtonText("إلغاء")
            .setAllowedAuthenticators(weak).build())
    }

    override fun onStart() { super.onStart(); OverlayCore.hide(this) }
    override fun onStop() { OverlayCore.show(this); super.onStop() }

    private fun buildUi() {
        val hud = JarvisHud(this)
        hud.setOnLongClickListener { startActivity(Intent(this, SettingsActivity::class.java)); true }
        setContentView(FrameLayout(this).apply { addView(hud, FrameLayout.LayoutParams(-1, -1)) })
        if (Brain.get(this, "key").isBlank()) startActivity(Intent(this, SettingsActivity::class.java))
        val missing = need.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startService() else requestPermissions(missing.toTypedArray(), 1)
    }

    private fun startService() = ContextCompat.startForegroundService(this, Intent(this, JarvisService::class.java))

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startService()
    }
}
