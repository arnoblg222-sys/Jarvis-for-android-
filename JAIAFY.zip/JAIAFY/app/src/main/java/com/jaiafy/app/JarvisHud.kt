package com.jaiafy.app
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** الكرة الزرقاء J.A.I.A.F.Y: حلقات متحدة المركز ونواة نابضة. تتحول إلى الأحمر في وضع Serious. */
class JarvisHud(c: Context) : View(c) {
    private val t0 = System.nanoTime()
    private val st = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fl = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val tx = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    var overlayMode = false

    private fun col(a: Int, rgb: Int) = (a shl 24) or (rgb and 0xFFFFFF)

    private fun arc(cv: Canvas, cx: Float, cy: Float, r: Float, start: Float, sweep: Float,
                    width: Float, color: Int, dash: FloatArray? = null) {
        st.strokeWidth = width; st.color = color
        st.pathEffect = dash?.let { DashPathEffect(it, 0f) }
        cv.drawArc(cx - r, cy - r, cx + r, cy + r, start, sweep, false, st)
        st.pathEffect = null
    }

    override fun onDraw(cv: Canvas) {
        val t = (System.nanoTime() - t0) / 1e9f
        val s = Mode.serious
        val main = if (s) 0xFF4D4D else 0x5FE3FF
        val band = if (s) 0xC62828 else 0x1E88E5
        val bandHi = if (s) 0xFF8A80 else 0x8FE9FF
        val deep = if (s) 0x1A0507 else 0x031624
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h / 2f
        val R = minOf(w, h) * 0.46f
        if (!overlayMode) { fl.shader = null; fl.color = col(0xFF, if (s) 0x0A0203 else 0x02070D); cv.drawRect(0f, 0f, w, h, fl) }

        arc(cv, cx, cy, R, t * 10f, 110f, 10f, col(0x33, main))
        arc(cv, cx, cy, R, t * 10f, 110f, 3f, col(0xFF, main))
        arc(cv, cx, cy, R, t * 10f + 130f, 100f, 3f, col(0xFF, main))
        arc(cv, cx, cy, R, t * 10f + 250f, 90f, 3f, col(0xFF, main))

        st.strokeWidth = 2f; st.color = col(0xCC, main); st.pathEffect = null
        for (i in 0 until 120) {
            val a = Math.toRadians((i * 3f - t * 4f).toDouble())
            val r1 = R * 0.92f; val r2 = r1 + R * (if (i % 5 == 0) 0.05f else 0.025f)
            cv.drawLine(cx + (r1 * cos(a)).toFloat(), cy + (r1 * sin(a)).toFloat(),
                cx + (r2 * cos(a)).toFloat(), cy + (r2 * sin(a)).toFloat(), st)
        }

        val seg = floatArrayOf(R * 0.06f, R * 0.012f)
        arc(cv, cx, cy, R * 0.79f, 140f + t * 6f, 220f, R * 0.13f, col(0xCC, band), seg)
        arc(cv, cx, cy, R * 0.79f, t * 50f, 36f, R * 0.07f, col(0xCC, bandHi), seg)
        arc(cv, cx, cy, R * 0.865f, 0f, 360f, 2f, col(0x88, main))
        arc(cv, cx, cy, R * 0.715f, 0f, 360f, 2f, col(0x88, main))

        arc(cv, cx, cy, R * 0.66f, 200f + sin(t) * 8f, 75f, 5f, col(0xFF, 0xFFB300))
        arc(cv, cx, cy, R * 0.66f, 285f, 22f, 2f, col(0x99, 0xFFB300))
        fl.shader = null; fl.color = col(0xFF, 0xFFD54F)
        for (i in 0 until 6) {
            val a = Math.toRadians((245f + i * 7f).toDouble())
            cv.drawCircle(cx + (R * 0.88f * cos(a)).toFloat(), cy + (R * 0.88f * sin(a)).toFloat(), 3f, fl)
        }

        fl.color = col(if (overlayMode) 0x88 else 0xDD, deep)
        cv.drawCircle(cx, cy, R * 0.58f, fl)
        arc(cv, cx, cy, R * 0.58f, 0f, 360f, 3f, col(0xCC, main))
        arc(cv, cx, cy, R * 0.5f, -t * 25f, 360f, 2f, col(0x99, main), floatArrayOf(R * 0.03f, R * 0.03f))
        arc(cv, cx, cy, R * 0.42f, 0f, 360f, 1f, col(0x55, main))
        st.strokeWidth = 1f; st.color = col(0x33, main)
        for (i in 0 until 24) {
            val a = Math.toRadians((i * 15f + t * 3f).toDouble())
            cv.drawLine(cx + (R * 0.42f * cos(a)).toFloat(), cy + (R * 0.42f * sin(a)).toFloat(),
                cx + (R * 0.58f * cos(a)).toFloat(), cy + (R * 0.58f * sin(a)).toFloat(), st)
        }

        val pulse = 1f + 0.05f * sin(t * 3f)
        fl.shader = RadialGradient(cx, cy, R * 0.45f * pulse,
            intArrayOf(col(0x55, main), 0x00000000), null, Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, R * 0.45f * pulse, fl)
        fl.shader = null

        val name = "J.A.I.A.F.Y."
        tx.textSize = R * 0.2f
        tx.textSize = tx.textSize * (R * 0.95f / tx.measureText(name))
        tx.color = Color.WHITE; tx.setShadowLayer(R * 0.08f, 0f, 0f, col(0xFF, main))
        cv.drawText(name, cx, cy + tx.textSize / 3f, tx)
        tx.clearShadowLayer(); tx.color = col(0xFF, main); tx.textSize = R * 0.09f
        cv.drawText("جايفاي", cx, cy + R * 0.24f, tx)

        postInvalidateOnAnimation()
    }
}
