package com.jaiafy.app
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.widget.LinearLayout
import android.widget.TextView

/** لوح زجاجي أزرق بأسلوب جارفيس: يُسحب من شريط العنوان، ويصبح إطاره برتقالياً عند اختياره. */
class GlassPanel(ctx: Context, titleText: String, private val onSelect: (GlassPanel) -> Unit) : LinearLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val box = GradientDrawable().apply { cornerRadius = 14 * d; setColor(0xC00A1F33.toInt()) }
    val titleView = TextView(ctx).apply {
        text = "▪ $titleText"; setTextColor(0xFF5FE3FF.toInt()); textSize = 12f
        setPadding((4 * d).toInt(), (2 * d).toInt(), (4 * d).toInt(), (8 * d).toInt())
    }

    init {
        orientation = VERTICAL
        background = box
        val p = (10 * d).toInt()
        setPadding(p, p, p, p)
        addView(titleView)
        select(false)
        var lx = 0f
        var ly = 0f
        titleView.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY; bringToFront(); onSelect(this); true }
                MotionEvent.ACTION_MOVE -> { x += e.rawX - lx; y += e.rawY - ly; lx = e.rawX; ly = e.rawY; true }
                else -> true
            }
        }
    }

    fun select(on: Boolean) {
        box.setStroke(((if (on) 3 else 2) * d).toInt(), if (on) 0xFFFFA000.toInt() else 0xFF2FB6D8.toInt())
    }

    fun addRow(text: String): TextView {
        val tv = TextView(context).apply {
            this.text = text; setTextColor(0xFFCFEFFF.toInt()); textSize = 12f
            setPadding((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt())
        }
        addView(tv)
        return tv
    }
}
