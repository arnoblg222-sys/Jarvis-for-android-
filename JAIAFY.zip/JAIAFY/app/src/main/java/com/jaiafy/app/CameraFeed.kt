package com.jaiafy.app
import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.provider.Settings
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.ByteArrayOutputStream
import kotlin.math.abs

/** يعرض بث كاميرا المراقبة (RTSP أو غيره) كنافذة عامة فوق كل التطبيقات. */
object CameraFeed {
    private var root: FrameLayout? = null
    private var player: ExoPlayer? = null
    private var pv: PlayerView? = null

    fun show(c: Context, url: String) {
        if (url.isBlank() || !Settings.canDrawOverlays(c)) return
        hide(c)
        val ctx = ContextThemeWrapper(c.applicationContext, android.R.style.Theme_Material_NoActionBar)
        val d = ctx.resources.displayMetrics.density
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = LayoutInflater.from(ctx).inflate(R.layout.cam_view, null) as PlayerView
        val exo = ExoPlayer.Builder(ctx).build()
        exo.setMediaItem(MediaItem.fromUri(url)); exo.prepare(); exo.playWhenReady = true
        view.player = exo

        val box = FrameLayout(ctx).apply { setBackgroundColor(0xFF02070D.toInt()) }
        box.addView(view, FrameLayout.LayoutParams(-1, -1))
        val title = TextView(ctx).apply {
            text = "▪ كاميرا المراقبة"; setTextColor(0xFF5FE3FF.toInt()); textSize = 12f
            setBackgroundColor(0xAA0A1F33.toInt()); setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
        }
        box.addView(title, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        val close = TextView(ctx).apply {
            text = "✕"; setTextColor(0xFFFFA000.toInt()); textSize = 14f
            setPadding((12 * d).toInt(), (4 * d).toInt(), (12 * d).toInt(), (4 * d).toInt())
            setOnClickListener { hide(c) }
        }
        box.addView(close, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))

        val lp = WindowManager.LayoutParams((300 * d).toInt(), (190 * d).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 120 }
        title.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                    MotionEvent.ACTION_MOVE -> { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(box, lp) }
                }
                return true
            }
        })
        try { wm.addView(box, lp); root = box; player = exo; pv = view } catch (_: Exception) { exo.release() }
    }

    fun hide(c: Context) {
        player?.release(); player = null; pv = null
        val r = root ?: return
        try { (c.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(r) } catch (_: Exception) {}
        root = null
    }

    /** لقطة من البث الحالي (JPEG) لإرسالها للعقل ليصف ما يحدث. يجب استدعاؤها من الخيط الرئيسي. */
    fun snapshot(): ByteArray? {
        val bmp = (pv?.videoSurfaceView as? TextureView)?.bitmap ?: return null
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return out.toByteArray()
    }
}
