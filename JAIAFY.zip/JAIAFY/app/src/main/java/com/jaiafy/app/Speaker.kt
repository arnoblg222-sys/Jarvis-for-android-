package com.jaiafy.app
import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** نطق: Fish Audio إن وُجد مفتاحه، وإلا (أو عند الفشل) صوت الجوال العربي. */
class Speaker(private val ctx: Context) {
    private var ready = false
    private val main = Handler(Looper.getMainLooper())
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("ar"); tts.setPitch(0.75f); tts.setSpeechRate(0.95f); ready = true
            }
        }
    }

    fun say(text: String, onDone: () -> Unit = {}) {
        val key = Brain.get(ctx, "fish_key")
        if (key.isBlank()) { sayLocal(text, onDone); return }
        Thread {
            val f = fishToFile(key, text)
            main.post { if (f != null) play(f, text, onDone) else sayLocal(text, onDone) }
        }.start()
    }

    private fun fishToFile(key: String, text: String): File? = try {
        val body = JSONObject().put("text", text).put("format", "mp3")
        val voice = Brain.get(ctx, "fish_voice")
        if (voice.isNotBlank()) body.put("reference_id", voice)
        val con = URL("https://api.fish.audio/v1/tts").openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true
        con.connectTimeout = 15000; con.readTimeout = 30000
        con.setRequestProperty("Content-Type", "application/json")
        con.setRequestProperty("Authorization", "Bearer $key")
        con.setRequestProperty("model", "s2.1-pro-free")
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        if (con.responseCode !in 200..299) null
        else {
            val f = File(ctx.cacheDir, "say.mp3")
            con.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            f
        }
    } catch (e: Exception) { null }

    private fun play(f: File, text: String, onDone: () -> Unit) {
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.path)
            mp.setOnCompletionListener { it.release(); onDone() }
            mp.setOnErrorListener { p, _, _ -> p.release(); sayLocal(text, onDone); true }
            mp.setOnPreparedListener { it.start() }
            mp.prepareAsync()
        } catch (e: Exception) { sayLocal(text, onDone) }
    }

    private fun sayLocal(text: String, onDone: () -> Unit) {
        if (!ready) { onDone(); return }
        tts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { onDone() }
            @Deprecated("") override fun onError(id: String?) { onDone() }
        })
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jaiafy")
    }

    fun shutdown() { tts.shutdown() }
}
